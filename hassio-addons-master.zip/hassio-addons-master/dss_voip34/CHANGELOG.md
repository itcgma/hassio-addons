# Changelog

## 3.4.1
⬆️ Upgrades add-on base image to v8.0.3


## 3.4.0


