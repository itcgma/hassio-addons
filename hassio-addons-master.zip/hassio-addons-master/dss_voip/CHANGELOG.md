# Changelog
## 3.5.7
⬆️ Upgrades add-on base image to v9.1.7


## 3.5.3
fix eol


## 3.5.1
⬆️ Upgrades add-on base image to v9.0.1
⬆️ Upgrades wget to 1.21.1-r1
⬆️ Upgrades coreutils to 8.32-r2


## 3.4.1
⬆️ Upgrades add-on base image to v8.0.3

