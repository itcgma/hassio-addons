# SDeSalve's Home Assistant Add-ons

## Some Hass.io add-ons for Home Assistant


Enable this plugin repository for [Hass.io](https://home-assistant.io/hassio/) following the [third party addon guide](https://home-assistant.io/hassio/installing_third_party_addons/). 

As repository add `https://github.com/sdesalve/hassio-addons`


[![Buy me a coffee][buymeacoffee-shield]][buymeacoffee] [![Support my work on Paypal][paypal-shield]][paypal]
[buymeacoffee-shield]: https://www.buymeacoffee.com/assets/img/guidelines/download-assets-sm-2.svg
[buymeacoffee]: https://www.buymeacoffee.com/sdesalve
[paypal-shield]: https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif
[paypal]: https://paypal.me/SDeSalve
